public class Main {
    public static void main(String[] args) {
        var numero = 0;
        for (; numero <= 3; numero = numero + 1) {

            System.out.println(numero);
        }
    }
}