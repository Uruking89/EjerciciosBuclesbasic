public class Main {
    public static void main(String[] args) {
        var contador = 8;

        if (contador > 0) {
            System.out.println("Es positivo");
        } else if (contador < 0) {
            System.out.println("Es negativo");
        }

    }
}


