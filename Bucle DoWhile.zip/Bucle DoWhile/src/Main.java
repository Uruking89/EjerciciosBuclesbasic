public class Main {
    public static void main(String[] args) {
        int contador = 2;

        do {
            System.out.println(contador + 1);
            contador = contador + 1;
        } while (contador <= 3);


    }
}